These examples demonstrate two simple applications built using TraitsUI

- a Python source code browser,
- a length measurement converter between various unit systems.