These examples demonstrate two useful features of TraitsUI

- Controlling the height and width of Groups in your TraitsUI application,
- Spacing widgets in your TraitsUI application using springs.