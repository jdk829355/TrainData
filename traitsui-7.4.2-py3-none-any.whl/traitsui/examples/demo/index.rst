.. image:: traits_ui_demo.jpg
