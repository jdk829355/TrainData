These examples demonstrate advanced features of TraitsUI.
